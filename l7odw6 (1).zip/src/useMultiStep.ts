import { ReactElement, useState } from "react";

//Custom Hook for form project. Treats parameter steps as an array off
//type ReactElement ***************************************
//wherein each element in ReactElement array counts as a step.
//React Elements are pure objects, not components.
export function useMultiStep(steps: ReactElement[]) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  function next() {
    setCurrentStepIndex((i) => {
      //If i is greater than or equal to the length of steps[] - 1, return value of i
      //Else return i incremented 1
      if (i >= steps.length - 1) return i;
      return i + 1;
    });
  }

  function back() {
    setCurrentStepIndex((i) => {
      //If i is less than or equal to 0, return i
      //Else return i decremented 1
      if (i <= 0) return i;
      return i - 1;
    });
  }

  function goTo(index: number) {
    setCurrentStepIndex(index);
  }

  return {
    currentStepIndex,
    step: steps[currentStepIndex], //Sets step equal to steps{curentStepIndex}?
    steps,
    isFirstStep: currentStepIndex === 0,
    isLastStep: currentStepIndex === steps.length - 1,
    goTo,
    next,
    back
  };
}
