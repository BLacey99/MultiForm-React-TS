//ReactNode import allows utilizing react components as types/properties.
import { ReactNode } from "react";

//Creates custom type for FormWrapper properties. Title will be added as
//a tag in component elements, children ReactNode iterates through all children
//of that element, and treats them as individual properties which get formatted
//accordingly.
type FormWrapperProps = {
  title: string;
  children: ReactNode;
};

//Exports FormWrapper components which expects object title, and children, of custom
//type FormWrapperProps
//Any react component that this wrapper goes around will require a title property
// to be set in the wrapper instantiation, and will take all elements of that
//component as the children property for FormerWrapperProps because ReactNode.
export function FormWrapper({ title, children }: FormWrapperProps) {
  return (
    <>
      <h2
        style={{
          textAlign: "center",
          margin: 0,
          marginBottom: "2rem"
        }}
      >
        {title}
      </h2>

      <div
        style={{
          display: "grid",
          gap: "1rem .5rem",
          justifyContent: "flex-start",
          gridTemplateColumns: "auto minmax(auto, 400px)"
        }}
      >
        {children}
      </div>
    </>
  );
}
