import { FormWrapper } from "./FormWrapper";

type UserData = {
  firstName: string
  lastName: string
  age: string
}

//Partial allows to use literally part of an existing type/object already.
//This is why we don't need to add all the properties of UserData.
type userFormProps = UserData & {
  //Takes current value of UserData from origin file. 
  //Uses partial modifier to allow for incomplete pull of UserData.
  updateFields: (fields: Partial<UserData>) => void
}

export function UserForm({firstName, lastName, age, updateFields}: userFormProps) {
  return (
    <FormWrapper title="User Details">
      <label>First Name</label>
      <input autoFocus required type="text" value={firstName} onChange={e => updateFields({firstName: e.target.value})} />
      <label>Last Name</label>
      <input required type="text" value={lastName} onChange={e => updateFields({lastName: e.target.value})}/>
      <label>Age</label>
      <input required type="number" value={age} onChange ={ e => updateFields({age: e.target.value})}/>
    </FormWrapper>
  );
}
